package com.main.functions;

//import javax.persistence.EntityManager;
//
//import org.hibernate.Session;
//import org.hibernate.query.Query;
//import org.springframework.beans.factory.annotation.Autowired;
//
//import com.main.model.Customers;

public class Functions {

//	@Autowired
//	private EntityManager entityMgnr;
	
	public void updateCustomer(String cid) {
//		Session currentSession = entityMgnr.unwrap(Session.class);
//		Query<Customers> query = currentSession.createQuery("from Customers", Customers.class);
	}
}
