export class Message {
    message_code:string;
    description:string;
}
