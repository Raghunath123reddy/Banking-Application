export class Login {
    uname:string;
    pswd:string;
}
