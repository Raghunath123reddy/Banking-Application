export class Customers {
    cust_id:string;
    cust_name:string;
    clear_balance:number;
    overdraft:string;
}
