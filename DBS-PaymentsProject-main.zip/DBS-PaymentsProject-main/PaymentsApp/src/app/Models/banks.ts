export class Banks {
    bic:string;
    bname:string;
}
