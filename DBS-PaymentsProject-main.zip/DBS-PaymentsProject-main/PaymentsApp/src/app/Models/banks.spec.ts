import { Banks } from './banks';

describe('Banks', () => {
  it('should create an instance', () => {
    expect(new Banks()).toBeTruthy();
  });
});
